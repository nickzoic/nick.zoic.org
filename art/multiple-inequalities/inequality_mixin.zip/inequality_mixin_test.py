#!/usr/bin/python

# This really should use unittest but I just couldn't be bothered right now.

import os
os.environ['APPLICATION_ID']='foo'

from google.appengine.api import apiproxy_stub_map
from google.appengine.api import datastore_file_stub
from google.appengine.ext import db

stub = datastore_file_stub.DatastoreFileStub('foo', '/dev/null', '/dev/null')
apiproxy_stub_map.apiproxy.RegisterStub('datastore_v3', stub) 

from inequality_mixin import MultiInequalityMixin

class Thingy(MultiInequalityMixin, db.Model):
    foo = db.IntegerProperty()
    bar = db.IntegerProperty()
    
    def __repr__(self):
        return "[%d, %d]" % (self.foo, self.bar)
        
a = Thingy(foo=1, bar=1); a.put()
b = Thingy(foo=2, bar=1); b.put()
c = Thingy(foo=3, bar=1); c.put()
d = Thingy(foo=1, bar=2); d.put()
e = Thingy(foo=2, bar=2); e.put()
f = Thingy(foo=3, bar=2); f.put()
g = Thingy(foo=1, bar=3); g.put()
h = Thingy(foo=2, bar=3); h.put()
i = Thingy(foo=3, bar=3); i.put()

assert(Thingy.all().filter("foo >", 1).filter("bar <=", 2).count() == 4)

l0 = [ b, c, e, f ]
l1 = [ x for x in Thingy.all().filter("foo >", 1).filter(" bar <= ", 2) ]
l2 = Thingy.all().filter("foo >", 1).filter("bar <=", 2).fetch(10)

assert(repr(l0) == repr(l1) == repr(l2))

x0 = [ a, c, g, i ]
x1 = [ x for x in Thingy.all().filter("foo !=", 2).filter("bar !=", 2) ] 
x2 = Thingy.all().filter("foo !=", 2).filter("bar !=", 2).fetch(10)

assert(repr(x0) == repr(x1) == repr (x2))

y0 = [ b, e, h ]
y1 = [ x for x in Thingy.all().filter("foo !=", 1).filter("foo !=", 3) ] 
y2 = Thingy.all().filter("foo !=", 1).filter("foo !=", 3).fetch(10)

assert(repr(y0) == repr(y1) == repr(y2))

print "Success!  No assertions thrown!"
   